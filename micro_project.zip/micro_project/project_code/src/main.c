#include "lcd.h"
#include "keypad.h"
#include "eeprom.h"
#include "interrupt.h"
#include "i2c_master.h"
#include "ds1307.h"
#include "usart.h"
#include <avr/pgmspace.h>
#include "fourth&sixth.h"
#define F_CPU 1000000UL

#define num_of_menu_options 8
#define size_of_datetime 0
#define STOP (_delay_ms(500))
#define GOOD_DELAY (_delay_ms(10))

// void lcd_show_string(char * str){
//     while(*str){
//         lcd_data(*str);
//         str++;
//     }
// }

// void circular_shift(const char*str,int delay_ms){
//     unsigned char len=strlen(str);
//     char buffer_line_1[17];
//     char buffer_line_2[17];
//     buffer_line_1[16]='\0';
//     buffer_line_2[16]='\0';
//     for(int i=0;i<len;i++){
//         for(int j=0;j<16;j++){
//             //nemikham \0 bida toye buffer ham    in if bara hamineh
//             if(i+j==len-1){
//                 buffer_line_1[j]=str[(i+j+1)%len];
//                 buffer_line_2[j]=str[(i+j+16)%len];
//             }
//             else if(i+j+16==len-1){
//                 buffer_line_1[j]=str[(i+j)%len];
//                 buffer_line_2[j]=str[(i+j+16+1)%len];
//             }
//             else{
//                 buffer_line_1[j]=str[(i+j)%len];
//                 buffer_line_2[j]=str[(i+j+16)%len];
//             }
//         }
//     }
// }

void convert_num_of_studs_to_ASCII(unsigned char num, char *ascii)
{
    if (num < 10)
    {
        ascii[0] = '0' + num;
        ascii[1] = '\0';
    }
    else if (num >= 10)
    {
        ascii[0] = '0' + num / 10;
        ascii[1] = '0' + num % 10;
        ascii[2] = '\0';
    }
}

// void show_text_in2lines(char *str)
// {
//     char buffer[17];
//     strncpy(buffer, str, 16);
//     buffer[16] = '\0';
//     lcd_command(0x80);
//     for (int i = 0; i < 16; i++)
//     {
//         lcd_data(buffer[i]);
//     }
//     unsigned char len = strlen(str);
//     unsigned char temp = len - 16;
//     strncpy(buffer, str + 16, temp);
//     buffer[temp] = '\0';
//     lcd_command(0xC0);
//     for (unsigned char i = 0; i < temp; i++)
//     {
//         lcd_data(buffer[i]);
//     }
// }

void show_text_in2lines(char *str)
{
    unsigned char twoLine = 1;
    unsigned char i = 0;
    while (str[i] != 0)
    {
        lcd_data(str[i]);
        i++;
    }
}

void enter_choice()
{
    char buffer[17];
    strcpy(buffer, "number: ");
    unsigned char len = strlen(buffer);
    for (unsigned char i = 0; i < len; i++)
    {
        lcd_data(buffer[i]);
    }
}
void error_invalid_student_code()
{
    char buffer[] = "invalid student code";
    show_text_in2lines(buffer);
    _delay_ms(2);
    lcd_command(0x01);
    DDRD |= (1 << 7);
    PORTD |= (1 << 7);
    _delay_ms(1);
    PORTD &= ~(1 << 7);
}

unsigned char checking_iteration(char *code)
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0);
    unsigned char i = 1;
    while (1)
    {
        if (num_of_students == 0)
        {
            return 0;
        }
        char code_temp[9];
        for (unsigned char i1 = 0; i1 < 8; i1++)
        {
            code_temp[i1] = eeprom_read_byte((uint8_t *)i);
            i++;
        }
        code_temp[8] = '\0';
        if (strcmp(code_temp, "00000000") != 0)
        {
            num_of_students--;
            if (strcmp(code_temp, code) == 0)
            {
                return 1;
            }
        }
        i += size_of_datetime;
    }
}

unsigned char empty_address()
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0x00);
    unsigned char i = 1;
    while (1)
    {
        if (num_of_students == 0)
        {
            return i;
        }
        char code_temp[9];
        for (unsigned char i1 = 0; i1 < 8; i1++)
        {
            code_temp[i1] = eeprom_read_byte((uint8_t *)i);
            i++;
        }
        code_temp[8] = '\0';
        if (strcmp(code_temp, "00000000") == 0)
        {
            return i - 8;
        }
        else
        {
            i += size_of_datetime;
            num_of_students--;
        }
    }
}

unsigned char eliminating(char *code)
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0x00);
    unsigned char i = 1;
    while (1)
    {
        if (num_of_students == 0)
        {
            return 0;
        }
        char code_temp[9];
        for (unsigned char i1 = 0; i1 < 8; i1++)
        {
            code_temp[i1] = eeprom_read_byte((uint8_t *)i);
            i++;
        }
        code_temp[8] = '\0';
        if (strcmp(code_temp, code) == 0)
        {
            for (unsigned char i1 = 1; i1 < 9; i1++)
            {
                eeprom_write_byte((uint8_t *)(i - i1), '0');
            }
            return 1;
        }
        else if (strcmp(code_temp, "00000000") != 0)
        {
            num_of_students--;
        }
        i += size_of_datetime;
    }
}

void increasing_num_of_students()
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0x00);
    num_of_students++;
    eeprom_write_byte((uint8_t *)0x00, num_of_students);
}

void decreasing_num_of_students()
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0x00);
    num_of_students--;
    eeprom_write_byte((uint8_t *)0x00, num_of_students);
}

void showing_students_code()
{
    unsigned char num_of_students = eeprom_read_byte((uint8_t *)0x00);
    unsigned char i = 1;
    while (1)
    {
        if (num_of_students == 0)
        {
            return 0;
        }
        char code_temp[9];
        for (unsigned char i1 = 0; i1 < 8; i1++)
        {
            code_temp[i1] = eeprom_read_byte((uint8_t *)i);
            i++;
        }
        code_temp[8] = '\0';
        if (strcmp(code_temp, "00000000") != 0)
        {
            num_of_students--;
            for (unsigned char i = 0; i < 8; i++)
            {
                lcd_data(code_temp[i]);
            }
            for (unsigned char i = 0; i < 4; i++)
            {
                GOOD_DELAY;
            }
            lcd_command(0x01);
        }
        i += size_of_datetime;
    }
}

void showing_inside_eeprom()
{
    lcd_command(0x01);
    unsigned char num_of_studs = eeprom_read_byte(0x00);
    char num_of_studs_string[3];
    convert_num_of_studs_to_ASCII(num_of_studs, num_of_studs_string);
    char buffer1[] = "num of students:";
    unsigned char len1 = strlen(buffer1);
    for (unsigned char i = 0; i < len1; i++)
    {
        lcd_data(buffer1[i]);
    }
    lcd_command(0xC0);
    unsigned char len2 = strlen(num_of_studs_string);
    for (unsigned char i = 0; i < len2; i++)
    {
        lcd_data(num_of_studs_string[i]);
    }
    _delay_ms(20);
    lcd_command(0x01);
    for (unsigned char i = 1; i < EEPROM_NUM; i++)
    {
        lcd_data(eeprom_read_byte((uint8_t *)i));
        if ((i % 8) == 0)
        {
            _delay_ms(100);
            lcd_command(0x01);
        }
        _delay_ms(20);
        // lcd_command(0x01);
    }
}

void main()
{
    keypad_init();
    interrupt_init();
    lcd_init();

    char menu_options[num_of_menu_options][50];
    strcpy(menu_options[0], "1.Attendance Initilization");
    strcpy(menu_options[1], "2.Student Management");
    strcpy(menu_options[2], "3.View Present Students");
    strcpy(menu_options[3], "4.Temperature Monitoring");
    strcpy(menu_options[4], "5.Retrieve Student Data");
    strcpy(menu_options[5], "6.Traffic Monitoring");
    strcpy(menu_options[6], "7.clearing data for new start");
    strcpy(menu_options[7], "8.eliminating student");

    //    char datetime[size_of_datetime];
    // i2c_init();
    // ds1307_init();

    while (1)
    {
        unsigned char i = 0;
        char menu_option_num;
        while (i < num_of_menu_options)
        {
            show_text_in2lines(menu_options[i]);
            for (unsigned char i = 0; i < 4; i++)
            {
                GOOD_DELAY;
            }
            lcd_command(0x01);
            i++;
        }
        enter_choice();
        menu_option_num = keypad_scan();
        keypad_init();
        if (menu_option_num == '1')
        {
            while (1)
            {
                lcd_command(0x01);
                char submenu_options[2][50];
                strcpy(submenu_options[0], "1.Submit Student Code");
                strcpy(submenu_options[1], "2.Exit");
                unsigned char i1 = 0;
                while (i1 < 2)
                {
                    show_text_in2lines(submenu_options[i1]);
                    for (unsigned char i = 0; i < 4; i++)
                    {
                        GOOD_DELAY;
                    }
                    lcd_command(0x01);
                    i1++;
                    ;
                }
                enter_choice();
                char option_num = keypad_scan();
                keypad_init();
                lcd_command(0x01);
                if (option_num == '1')
                {
                    char code[20];
                    unsigned char index = 0;
                    // ending by *
                    while (1)
                    {
                        char digit = keypad_scan();
                        keypad_init();
                        lcd_data(digit); // ta 16 ta ro neshoon mide
                        if (digit == '*')
                        {
                            _delay_ms(2);
                            lcd_command(0x01);
                            break;
                        }
                        else
                        {
                            code[index] = digit;
                            index++;
                        }
                    }
                    code[index] = '\0';
                    unsigned char size = strlen(code);
                    if (size != 8)
                    {
                        error_invalid_student_code();
                    }
                    else
                    {
                        unsigned char status = checking_iteration(code);
                        if (!status)
                        {
                            unsigned char address_of_eeprom = empty_address();
                            unsigned char len = strlen(code);
                            for (unsigned char i = 0; i < len; i++)
                            {
                                eeprom_write_byte((uint8_t *)address_of_eeprom, code[i]);
                                address_of_eeprom++;
                            }
                            // readRTC(datetime);
                            // saveToEEPROM(address_of_eeprom, datetime, size_of_datetime);
                            address_of_eeprom += size_of_datetime;
                            increasing_num_of_students();
                        }
                        else
                        {
                            char buffer[] = "iterative!";
                            unsigned char len = strlen(buffer);
                            for (unsigned char i = 0; i < len; i++)
                            {
                                lcd_data(buffer[i]);
                            }
                            for (unsigned char i = 0; i < 4; i++)
                            {
                                GOOD_DELAY;
                            }
                            lcd_command(0x01);
                        }
                    }
                }
                else if (option_num == '2')
                {
                    lcd_command(0x01);
                    break;
                }
            }
        }
        else if (menu_option_num == '2')
        {
            lcd_command(0x01);
            char buff[] = "code:";
            unsigned char len_buff = strlen(buff);
            for (unsigned char i = 0; i < len_buff; i++)
            {
                lcd_data(buff[i]);
            }
            lcd_command(0xC0);
            char code[20];
            unsigned char index = 0;
            // ending by *
            while (1)
            {
                char digit = keypad_scan();
                keypad_init();
                lcd_data(digit); // ta 16 ta ro neshoon mide
                if (digit == '*')
                {
                    _delay_ms(2);
                    lcd_command(0x01);
                    break;
                }
                else
                {
                    code[index] = digit;
                    index++;
                }
            }
            code[index] = '\0';
            lcd_command(0x01);
            unsigned char size = strlen(code);
            if (size == 8)
            {
                unsigned char status = checking_iteration(code);
                if (!status)
                {
                    char buffer[] = "abscent";
                    unsigned char len = strlen(buffer);
                    for (unsigned char i = 0; i < len; i++)
                    {
                        lcd_data(buffer[i]);
                    }
                    for (unsigned char i = 0; i < 4; i++)
                    {
                        GOOD_DELAY;
                    }
                }
                else
                {
                    char buffer[] = "present";
                    unsigned char len = strlen(buffer);
                    for (unsigned char i = 0; i < len; i++)
                    {
                        lcd_data(buffer[i]);
                    }
                    for (unsigned char i = 0; i < 4; i++)
                    {
                        GOOD_DELAY;
                    }
                }
                lcd_command(0x01);
            }
            else
            {
                error_invalid_student_code();
            }
        }
        else if (menu_option_num == '3')
        {
            lcd_command(0x01);
            unsigned char num_of_studs = eeprom_read_byte(0x00);
            char num_of_studs_string[3];
            convert_num_of_studs_to_ASCII(num_of_studs, num_of_studs_string);
            char buffer1[] = "num of students:";
            unsigned char len1 = strlen(buffer1);
            for (unsigned char i = 0; i < len1; i++)
            {
                lcd_data(buffer1[i]);
            }
            lcd_command(0xC0);
            unsigned char len2 = strlen(num_of_studs_string);
            for (unsigned char i = 0; i < len2; i++)
            {
                lcd_data(num_of_studs_string[i]);
            }
            for (unsigned char i = 0; i < 4; i++)
            {
                GOOD_DELAY;
            }
            lcd_command(0x01);
            showing_students_code();
            lcd_command(0x01);
        }
        else if (menu_option_num == '4')
        {
            lcd_command(0x01);
            lcd_print(" Temp:");
            int temp = 0;
            char buffer[16];
            ADMUX = 0xE0;
            ADCSRA = 0x87;

            while (global_variable)
            {

                ADCSRA |= 1 << ADSC;

                while ((ADCSRA & (1 << ADIF)) == 0)
                    ;

                if (ADCH != temp || 1)
                {

                    temp = ADCH;
                    snprintf(buffer, sizeof(buffer), "%d C", temp);
                    lcd_command(0xC0);
                    lcd_print(buffer);
                }

                if (global_variable == 0)
                {
                    lcd_command(0x01);
                    break;
                }
            }
            global_variable = 1;
        }
        else if (menu_option_num == '5')
        {
            lcd_command(0x01);

            // exit yadet nare
        }
        else if (menu_option_num == '6')
        {
            lcd_command(0x01);
            char numberString[16]; // Buffer to hold distance string
            uint16_t pulseWidth;   // Pulse width from echo
            int distance;          // Calculated distance
            int previous_count = -1;

            HCSR04Init(); // Initialize ultrasonic sensor

            while (global_variable)
            {
                _delay_ms(100); // Delay for sensor stability

                HCSR04Trigger();              // Send trigger pulse
                pulseWidth = GetPulseWidth(); // Measure echo pulse

                if (pulseWidth == US_ERROR)
                {
                    lcd_command(0x01);
                    lcd_print("Error"); // Display error message
                    GOOD_DELAY;
                }
                else if (pulseWidth == US_NO_OBSTACLE)
                {
                    lcd_command(0x01);
                    show_text_in2lines("No Obstacle"); // Display no obstacle message
                    GOOD_DELAY;
                }
                else
                {
                    distance = (int)((pulseWidth * 0.555 / 2) + 0.5);

                    // Display distance on LCD
                    sprintf(numberString, "%d", distance); // Convert distance to string
                    lcd_command(0x01);
                    lcd_print("Distance: ");
                    lcd_print(numberString);
                    lcd_print(" cm");

                    // Counting logic based on distance
                    if (distance < 6)
                    {
                        count++; // Increment count if distance is below threshold
                    }

                    // Update count on LCD only if it changes
                    if (count != previous_count)
                    {
                        previous_count = count;
                        lcd_command(0xC0); // Move to second line
                        sprintf(numberString, "%d", count);
                        lcd_print("Count: ");
                        lcd_print(numberString);
                    }
                }
                if (global_variable == 0)
                {
                    lcd_command(0x01);
                }
            }

            global_variable = 1;
        }
        else if (menu_option_num == '7')
        {
            lcd_command(0x01);
            eeprom_clear_all();
            char buffer[] = "clearation";
            unsigned char len = strlen(buffer);
            for (unsigned char i = 0; i < len; i++)
            {
                lcd_data(buffer[i]);
            }
            GOOD_DELAY;
            GOOD_DELAY;
            lcd_command(0x01);
        }
        else if (menu_option_num == '8')
        {
            lcd_command(0x01);
            char code[20];
            unsigned char index = 0;
            // ending by *
            while (1)
            {
                char digit = keypad_scan();
                keypad_init();
                lcd_data(digit); // ta 16 ta ro neshoon mide
                if (digit == '*')
                {
                    _delay_ms(2);
                    lcd_command(0x01);
                    break;
                }
                else
                {
                    code[index] = digit;
                    index++;
                }
            }
            code[index] = '\0';
            unsigned char size = strlen(code);
            if (size == 8)
            {
                if (!eliminating(code))
                {
                    char buffer[] = "no such code!";
                    unsigned char len = strlen(buffer);
                    for (unsigned char i = 0; i < len; i++)
                    {
                        lcd_data(buffer[i]);
                    }
                    for (unsigned char i = 0; i < 4; i++)
                    {
                        GOOD_DELAY;
                    }
                    lcd_command(0x01);
                }
                else
                {
                    decreasing_num_of_students();
                    char buffer[] = "done!";
                    unsigned char len = strlen(buffer);
                    for (unsigned char i = 0; i < len; i++)
                    {
                        lcd_data(buffer[i]);
                    }
                    for (unsigned char i = 0; i < 4; i++)
                    {
                        GOOD_DELAY;
                    }
                    lcd_command(0x01);
                }
            }
            else
            {
                error_invalid_student_code();
            }
        }
        else if (menu_option_num == '9')
        {
            showing_inside_eeprom();
        }
    }
    while (1)
        ;
}