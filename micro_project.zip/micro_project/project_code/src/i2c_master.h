
#ifndef I2C_MASTER_H
#define I2C_MASTER_H

#include <avr/io.h>
#include <util/delay.h>

#define SCL_CLOCK 100000UL // 100kHz

void i2c_start();
void i2c_stop();
void i2c_write(unsigned char data);
unsigned char i2c_read_ack();
unsigned char i2c_read_nack();

void i2c_init() {
 
    TWSR = 0x00; 
    TWBR = ((F_CPU / SCL_CLOCK) - 16) / 2;
    TWCR = (1 << TWEN); 
}

void i2c_start() {
    TWCR = (1 << TWSTA) | (1 << TWEN) | (1 << TWINT);
    while (!(TWCR & (1 << TWINT))); 
}

void i2c_stop() {
    TWCR = (1 << TWSTO) | (1 << TWEN) | (1 << TWINT);
}

void i2c_write(unsigned char data) {
    TWDR = data;
    TWCR = (1 << TWEN) | (1 << TWINT);
    while (!(TWCR & (1 << TWINT))); 
}

unsigned char i2c_read_ack() {
    TWCR = (1 << TWEN) | (1 << TWINT) | (1 << TWEA);
    while (!(TWCR & (1 << TWINT)));
    return TWDR;
}

unsigned char i2c_read_nack() {
    TWCR = (1 << TWEN) | (1 << TWINT);
    while (!(TWCR & (1 << TWINT)));
    return TWDR;
}



#endif