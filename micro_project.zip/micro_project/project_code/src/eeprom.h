#ifndef EEPROM_H_
#define EEPROM_H_
#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>

#define EEPROM_NUM 250

// void EEPROM_write(char data,unsigned char address){
//     while(EECR & (1<<EEWE));
//     EEAR=address;
//     EEDR=data;
//     EECR|=(1<<EEMWE);
//     EECR|=(1<<EEWE);
// }


// char EEPROM_read(unsigned char address){
//     while(EECR & (1<<EEWE));
//     EEAR=address;
//     EECR|=EERE;
//     return EEDR;
// }


void saveToEEPROM(unsigned char addr, char*data, unsigned char len) {
    unsigned char temp=addr;
    for (unsigned char i = 0; i < len; i++) {
        eeprom_write_byte((uint8_t*)temp,data[i]);
        temp++;
    }
}

//100 khaneye aval ra 0 mikonad ke haman hokm pak kardan ra darad 
//albataeh pak kardane kamel yani hameye khane hara sefr koni vali man nmeidanestam chand khaneh darad,faghat
//midanestam eshtebahan be tehdade kami khaneh tush neveshtam

void eeprom_clear_all(){
    char t=0;
    eeprom_write_byte(0x00,t);
    for(unsigned char i=1;i<EEPROM_NUM;i++){
       eeprom_write_byte((uint8_t*)i,'0');
    }
}

#endif