#ifndef INTERRUPT_H_
#define INTERRUPT_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "keypad.h"


void interrupt_init() {
	 // Enable external interrupt on INT2 (PB2)	
	  GICR |= (1 << INT2); // Trigger INT2 on falling edge
	  MCUCSR &= ~(1 << ISC2); // Enable global interrupts 
	  sei(); 
}

ISR(INT2_vect) {
	// Interrupt Service Routine for INT2
	lcd_command(0x01);
	global_variable = 0;
}






#endif