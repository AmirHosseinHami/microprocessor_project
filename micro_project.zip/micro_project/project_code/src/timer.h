#ifndef TIMER_H_
#define TIMER_H_

#include <avr/io.h>
#include <avr/interrupt.h>

volatile unsigned int timer_count = 0;  
volatile unsigned int timer_done = 0;    

void timer_start() {
    timer_count = 0;
    timer_done = 0;
    TCCR1B |= (1 << WGM12); 
    TCCR1B |= (1 << CS12) | (1 << CS10); 
    OCR1A = 9766; 
    TIMSK |= (1 << OCIE1A); 
    sei(); 
}

ISR(TIMER1_COMPA_vect) {//interrupt service routine(timer1 compare match mode)
    timer_count++;
    if (timer_count >= 900) { 
        timer_done = 1; 
        TCCR1B &= ~((1 << CS12) | (1 << CS10)); 
    }
}


#endif