#ifndef DS1307_H
#define DS1307_H

#include "i2c_master.h"

#define DS1307_ADDRESS 0xD0 

unsigned char bcd_to_decimal(unsigned char bcd) {
    return (bcd >> 4) * 10 + (bcd & 0x0F);
}

unsigned char decimal_to_bcd(unsigned char dec) {
    return ((dec / 10) << 4) | (dec % 10);
}

void ds1307_init() {
    i2c_start();
    i2c_write(DS1307_ADDRESS);
    i2c_write(0x00); 
    i2c_write(0x00); 
    i2c_stop();
}

void ds1307_set_datetime(unsigned char *datetime) {
    i2c_start();
    i2c_write(DS1307_ADDRESS);
    i2c_write(0x00); 
    for (unsigned char i = 0; i < 7; i++) {
        i2c_write(decimal_to_bcd(datetime[i]));
    }
    i2c_stop();
}

void ds1307_get_datetime(unsigned char *datetime) {
    i2c_start();
    i2c_write(DS1307_ADDRESS);
    i2c_write(0x00); 
    i2c_stop();

    i2c_start();
    i2c_write(DS1307_ADDRESS | 0x01);
    for (unsigned char i = 0; i < 6; i++) {
        datetime[i] = bcd_to_decimal(i2c_read_ack());
    }
    datetime[6] = bcd_to_decimal(i2c_read_nack());
    i2c_stop();
}

void readRTC(unsigned char *datetime) {
    ds1307_get_datetime(datetime); 
}


#endif