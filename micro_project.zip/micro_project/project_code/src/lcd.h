#include <avr/io.h>
#include <util/delay.h>

#define LCD_DPRT PORTC //LCD DATA PORT
#define LCD_DDDR DDRC //LCD DATA DDR
#define LCD_DPIN PINC //LCD DATA PIN
#define LCD_CPRT PORTD //LCD COMMANDS PORT
#define LCD_CDDR DDRD //LCD COMMANDS DDR
#define LCD_CPIN PIND //LCD COMMANDS PIN
#define LCD_EN 3 //LCD EN
#define LCD_RW 4 //LCD RW
#define LCD_RS 0 //LCD RS
#define SLEEP_TIME 500
 
/////////////////////////////////////



/////////////////////////////////////
#ifndef LCD_H_
#define LCD_H_


void lcd_command( unsigned char cmnd )
{
	LCD_DPRT = cmnd; //send cmnd to data port
	LCD_CPRT &= ~ (1<<LCD_RS); //RS = 0 for command
	LCD_CPRT &= ~ (1<<LCD_RW); //RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN); //EN = 1 for H-to-L pulse
	_delay_us(SLEEP_TIME); //wait to make enable wide
	LCD_CPRT &= ~ (1<<LCD_EN); //EN = 0 for H-to-L pulse
	_delay_us(SLEEP_TIME); //wait to make enable wide
}

void lcd_data( unsigned char data )
{
	LCD_DPRT = data; //send data to data port
	LCD_CPRT |= (1<<LCD_RS); //RS = 1 for data
	LCD_CPRT &= ~ (1<<LCD_RW); //RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN); //EN = 1 for H-to-L pulse
	_delay_us(SLEEP_TIME); //wait to make enable wide 2000
	LCD_CPRT &= ~ (1<<LCD_EN); //EN = 0 for H-to-L pulse
	_delay_us(SLEEP_TIME); //wait to make enable wide 2000
}

void lcd_init()
{
	LCD_DDDR = 0xFF;
	LCD_CDDR = 0xFF;
	LCD_CPRT &=~(1<<LCD_EN); //LCD_EN = 0
	_delay_us(SLEEP_TIME); //wait for init.
	lcd_command(0x38); //init. LCD 2 line, 5 × 7 matrix
	lcd_command(0x0C); //display on, cursor off
	lcd_command(0x01); //clear LCD
	_delay_us(SLEEP_TIME); //wait
	lcd_command(0x06); //shift cursor right
}void lcd_print( char * str )
{
	unsigned char i = 0;
	while(str[i]!=0)
	{
		lcd_data(str[i]);
		i++ ;
	}
}

#endif