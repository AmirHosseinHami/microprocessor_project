* for it to works set the configuation as in 
./micro_settings_config.png and virtual_termina_config.png

* if the virtual terminal doest load atomaticly in proteus , after runnning the project
go to -> (Debug / 4.Virtual Terminal)
 
