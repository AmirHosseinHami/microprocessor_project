#define F_CPU 16000000UL // Clock speed for atmega32

#include <mega32.h>       // Header for atmega32
#include <delay.h>        // To use for delay function
#include <stdint.h>
#include <stdio.h>

// Port definitions for easier reference
#define PC0 0  // Pin 0 of PORTC
#define PC1 1  // Pin 1 of PORTC
#define PB0 0  // Pin 0 of PORTB (Trigger)
#define PB1 1  // Pin 1 of PORTB (Echo)
#define PD0 0
#define PD1 1 
#define PD2 2


// LCD Definitions
#define lcd_port PORTD    // LCD connected to PORTD
#define lcd_data_dir DDRD // LCD data direction register
#define rs PD0            // RS pin connected to PD0
#define en PD1            // Enable pin connected to PD1

// Ultrasonic Sensor Definitions
#define US_PORT PORTB     // Ultrasonic sensor connected to PORTB
#define US_PIN PINB       // Ultrasonic PIN register
#define US_DDR DDRB       // Ultrasonic data direction register

#define US_TRIG_POS PB0   // Trigger pin connected to PB0
#define US_ECHO_POS PB1   // Echo pin connected to PB1

// Error indicators
#define US_ERROR -1       // Error indicator
#define US_NO_OBSTACLE -2 // No obstacle indicator

volatile int count = 0; // Counting variable

void HCSR04Init();
void HCSR04Trigger();
void lcd_command(unsigned char);
void lcd_clear();
void lcd_print(char *);
void lcd_setCursor(unsigned char, unsigned char);
uint16_t GetPulseWidth();

void HCSR04Init() {
    US_DDR |= (1 << US_TRIG_POS); // Trigger pin as output
    US_DDR &= ~(1 << US_ECHO_POS); // Echo pin as input
}

void HCSR04Trigger() {
    US_PORT |= (1 << US_TRIG_POS); // Set trigger pin high
    delay_us(15);                  // Wait for 15 microseconds
    US_PORT &= ~(1 << US_TRIG_POS); // Set trigger pin low
}

uint16_t GetPulseWidth() {
    uint32_t i, result;

    // Wait for rising edge on Echo pin
    for (i = 0; i < 600000; i++) {
        if (!(US_PIN & (1 << US_ECHO_POS)))
            continue;
        else
            break;
    }

    if (i == 600000)
        return US_ERROR; // Timeout error if no rising edge detected

    // Start timer with prescaler 8
    TCCR1A = 0x00;
    TCCR1B = (1 << CS11);
    TCNT1 = 0x00; // Reset timer

    // Wait for falling edge on Echo pin
    for (i = 0; i < 600000; i++) {
        if (!(US_PIN & (1 << US_ECHO_POS)))
            break;  // Falling edge detected
        if (TCNT1 > 60000)
            return US_NO_OBSTACLE; // No obstacle in range
    }

    result = TCNT1; // Capture timer value
    TCCR1B = 0x00; // Stop timer

    if (result > 60000)
        return US_NO_OBSTACLE;
    else
        return (result >> 1); // Return the measured pulse width
}

void initialize() {
    lcd_data_dir = 0xFF;   // Set LCD data direction
    delay_ms(15);
    lcd_command(0x02); // Return home
    lcd_command(0x28); // 4-bit mode, 2 lines, 5x7 font
    lcd_command(0x0C); // Display on, cursor off
    lcd_command(0x06); // Increment cursor
    lcd_command(0x01); // Clear display
    delay_ms(2);
}

void lcd_command(unsigned char cmnd) {
    // Send upper nibble
    lcd_port = (lcd_port & 0x0F) | (cmnd & 0xF0);
    lcd_port &= ~(1 << rs);  // RS pin low for command
    lcd_port |= (1 << en);   // Enable high
    delay_us(1);
    lcd_port &= ~(1 << en);  // Enable low

    // Send lower nibble
    lcd_port = (lcd_port & 0x0F) | (cmnd << 4);
    lcd_port |= (1 << en);   // Enable high
    delay_us(1);
    lcd_port &= ~(1 << en);  // Enable low
    delay_ms(2);
}

void lcd_clear() {
    lcd_command(0x01); // Clear LCD
    delay_ms(2);
    lcd_command(0x80); // Return to first line
}

void lcd_print(char *str) {
    int i;
    
    for (i = 0; str[i] != 0; i++) {
        lcd_port = (lcd_port & 0x0F) | (str[i] & 0xF0);
        lcd_port |= (1 << rs);  // RS pin high for data
        lcd_port |= (1 << en);  // Enable high
        delay_us(1);
        lcd_port &= ~(1 << en); // Enable low

        lcd_port = (lcd_port & 0x0F) | (str[i] << 4);
        lcd_port |= (1 << en);  // Enable high
        delay_us(1);
        lcd_port &= ~(1 << en); // Enable low
        delay_ms(2);
    }
}

void lcd_setCursor(unsigned char x, unsigned char y) {
    unsigned char adr[] = {0x80, 0xC0};
    lcd_command(adr[y - 1] + x - 1);
    delay_us(100);
}

void main() {
    char numberString[16];  // Buffer to hold distance string
    uint16_t pulseWidth;    // Pulse width from echo
    int distance;           // Calculated distance
    int previous_count = -1;

    initialize();           // Initialize LCD
    HCSR04Init();           // Initialize ultrasonic sensor

    while (1) {
        delay_ms(100);  // Delay for sensor stability

        HCSR04Trigger();              // Send trigger pulse
        pulseWidth = GetPulseWidth();  // Measure echo pulse

        if (pulseWidth == US_ERROR) {
            lcd_clear();
            lcd_setCursor(1, 1);
            lcd_print("Error");        // Display error message
        } else if (pulseWidth == US_NO_OBSTACLE) {
            lcd_clear();
            lcd_setCursor(1, 1);
            lcd_print("No Obstacle");  // Display no obstacle message
        } else {
            distance = (int)((pulseWidth * 0.034 / 2) + 0.5);

            // Display distance on LCD
            sprintf(numberString, "%d", distance); // Convert distance to string
            lcd_clear();
            lcd_setCursor(1, 1);
            lcd_print("Distance: ");
            lcd_print(numberString); 
            lcd_print(" cm");

            // Counting logic based on distance
            if (distance < 6) {
                count++;  // Increment count if distance is below threshold
            }

            // Update count on LCD only if it changes
            if (count != previous_count) {
                previous_count = count;
                lcd_setCursor(1, 2); // Move to second line
                sprintf(numberString, "%d", count);
                lcd_print("Count: ");
                lcd_print(numberString);
            }
        }
    }
}
